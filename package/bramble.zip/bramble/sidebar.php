<aside class="sidebar">
	<?php dynamic_sidebar( 'sidebar' ); ?>
</aside>