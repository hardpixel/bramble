//= require main

jQuery(document).ready(function($) {
	$('.gallery-item a').swipebox();
});
