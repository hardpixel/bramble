(function() {
  var $;

  $ = jQuery;

  $(document).ready(function() {});

}).call(this);
