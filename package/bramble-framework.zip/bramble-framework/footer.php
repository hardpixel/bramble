		</section>
	</main>

	<footer id="document-footer" role="contentinfo">
		<div class="footer-inner">
			<?php echo 'Footer'; ?>
		</div>
	</footer>

	<?php wp_footer(); ?>

</body>
</html>